/**
 * SSRF-safe URL validation for policy import (throws CrawlValidationError).
 */
import { lookup } from 'dns/promises';
import { isIP } from 'net';
import { CrawlValidationError } from '../../chatbot-cskh/utils/website-crawl.util';

function ipv4ToInt(ip: string): number {
  return ip.split('.').reduce((acc, oct) => (acc << 8) + Number(oct), 0) >>> 0;
}

function isPrivateOrReservedIp(ip: string): boolean {
  const v = isIP(ip);
  if (v === 4) {
    const n = ipv4ToInt(ip);
    const ranges: Array<[number, number]> = [
      [ipv4ToInt('0.0.0.0'), ipv4ToInt('0.255.255.255')],
      [ipv4ToInt('10.0.0.0'), ipv4ToInt('10.255.255.255')],
      [ipv4ToInt('127.0.0.0'), ipv4ToInt('127.255.255.255')],
      [ipv4ToInt('169.254.0.0'), ipv4ToInt('169.254.255.255')],
      [ipv4ToInt('172.16.0.0'), ipv4ToInt('172.31.255.255')],
      [ipv4ToInt('192.168.0.0'), ipv4ToInt('192.168.255.255')],
      [ipv4ToInt('100.64.0.0'), ipv4ToInt('100.127.255.255')],
      [ipv4ToInt('224.0.0.0'), ipv4ToInt('255.255.255.255')],
    ];
    return ranges.some(([a, b]) => n >= a && n <= b);
  }
  if (v === 6) {
    const lower = ip.toLowerCase();
    if (lower === '::1' || lower === '::') return true;
    if (lower.startsWith('fc') || lower.startsWith('fd')) return true; // ULA
    if (lower.startsWith('fe80')) return true; // link-local
    if (lower.startsWith('ff')) return true; // multicast
    const mapped = lower.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    if (mapped?.[1]) return isPrivateOrReservedIp(mapped[1]);
    // Public IPv6 is allowed
    return false;
  }
  return true;
}

export async function assertPublicHttpUrl(raw: string): Promise<URL> {
  const trimmed = (raw || '').trim();
  if (!trimmed) throw new CrawlValidationError('URL không được để trống.');

  let parsed: URL;
  try {
    parsed = new URL(trimmed);
  } catch {
    throw new CrawlValidationError('URL không hợp lệ.');
  }

  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new CrawlValidationError('URL phải bắt đầu bằng http:// hoặc https://');
  }
  if (parsed.username || parsed.password) {
    throw new CrawlValidationError('URL không được chứa thông tin đăng nhập.');
  }

  const host = parsed.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (!host || host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local')) {
    throw new CrawlValidationError('Không quét URL nội bộ.');
  }
  if (host === 'metadata.google.internal' || host.endsWith('.internal')) {
    throw new CrawlValidationError('Không quét URL nội bộ.');
  }

  if (isIP(host)) {
    if (isPrivateOrReservedIp(host)) {
      throw new CrawlValidationError('Không quét URL nội bộ.');
    }
  } else {
    let records: Array<{ address: string }>;
    try {
      records = await lookup(host, { all: true, verbatim: true });
    } catch {
      throw new CrawlValidationError('Không phân giải được tên miền.');
    }
    for (const rec of records) {
      if (isPrivateOrReservedIp(rec.address)) {
        throw new CrawlValidationError('Không quét URL nội bộ.');
      }
    }
  }

  return parsed;
}

export async function fetchPublicHtmlSafe(
  rawUrl: string,
  opts?: {
    timeoutMs?: number;
    maxBytes?: number;
    maxRedirects?: number;
    userAgent?: string;
  },
): Promise<{ finalUrl: string; title: string; text: string; html: string }> {
  const timeoutMs = opts?.timeoutMs ?? 12_000;
  const maxBytes = opts?.maxBytes ?? 1_500_000;
  const maxRedirects = opts?.maxRedirects ?? 3;
  const userAgent =
    opts?.userAgent ??
    'Mozilla/5.0 (compatible; AiBeeGo-PolicyImporter/1.0)';

  let current = await assertPublicHttpUrl(rawUrl);
  let redirects = 0;

  for (let hop = 0; hop <= maxRedirects; hop++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    let response: Response;
    try {
      response = await fetch(current.toString(), {
        method: 'GET',
        redirect: 'manual',
        headers: {
          'User-Agent': userAgent,
          Accept: 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.8',
          'Accept-Language': 'vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7',
        },
        signal: controller.signal,
      });
    } catch (e) {
      clearTimeout(timer);
      throw new CrawlValidationError(
        e instanceof Error && e.name === 'AbortError'
          ? 'Hết thời gian chờ khi tải trang.'
          : e instanceof Error
            ? e.message
            : 'Không tải được trang.',
      );
    } finally {
      clearTimeout(timer);
    }

    if ([301, 302, 303, 307, 308].includes(response.status)) {
      const loc = response.headers.get('location');
      if (!loc) throw new CrawlValidationError('Redirect thiếu Location.');
      redirects += 1;
      if (redirects > maxRedirects) {
        throw new CrawlValidationError('Quá nhiều lần redirect.');
      }
      current = await assertPublicHttpUrl(new URL(loc, current).toString());
      continue;
    }

    if (!response.ok) {
      throw new CrawlValidationError(`Máy chủ trả HTTP ${response.status}.`);
    }

    const reader = response.body?.getReader();
    if (!reader) throw new CrawlValidationError('Không đọc được nội dung trang.');
    const chunks: Uint8Array[] = [];
    let total = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      if (value) {
        total += value.byteLength;
        if (total > maxBytes) {
          try {
            await reader.cancel();
          } catch {
            /* ignore */
          }
          throw new CrawlValidationError('Trang quá lớn để phân tích.');
        }
        chunks.push(value);
      }
    }

    const html = Buffer.concat(chunks.map((c) => Buffer.from(c))).toString('utf8');
    const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
    const title = (titleMatch?.[1] || current.hostname).replace(/\s+/g, ' ').trim();
    const text = html
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 20_000);

    return { finalUrl: current.toString(), title, text, html };
  }

  throw new CrawlValidationError('Quá nhiều lần redirect.');
}
